#include "include/printConsole.h"
int main()
{
    run();
    return 0;
}
