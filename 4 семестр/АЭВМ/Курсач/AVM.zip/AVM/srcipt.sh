
   echo -e "\E[H\E[J"
   echo -e "\E[05;10H"
   echo -e "\E[40m\E[31mДаниил"
   echo -e "\E[06;8H"
   echo -e "\E[47m\E[32mИП-912"
   echo -e "\E[010;1H"
   echo -e "\E[00m\n"