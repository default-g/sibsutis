#include <iostream>
#include <string>

using namespace std;
string output;

void hundred_to_string(int hundred) {

  switch (hundred / 100) {
  case 1:
    output += "cто ";
    break;
  case 2:
    output += "двести ";
    break;
  case 3:
    output += "триста ";
    break;
  case 4:
    output += "четыреста ";
    break;
  case 5:
    output += "пятьсот ";
    break;
  case 6:
    output += "шестьсот ";
    break;
  case 7:
    output += "семьсот ";
    break;
  case 8:
    output += "восемьсот ";
    break;
  case 9:
    output += "девятьсот ";
    break;
  }
  switch ((hundred % 100) / 10) {
  case 2:
    output += "двадцать ";
    break;
  case 3:
    output += "тридцать ";
    break;
  case 4:
    output += "сорок ";
    break;
  case 5:
    output += "пятьдесят ";
    break;
  case 6:
    output += "шестьдесят ";
    break;
  case 7:
    output += "семьдесят ";
    break;
  case 8:
    output += "восемьдесят ";
    break;
  case 9:
    output += "девяносто ";
    break;
  }
  if (hundred % 100 >= 10 & hundred % 100 < 20) {
    switch (hundred % 100) {
    case 10:
      output += "десять ";
      break;
    case 11:
      output += "одиннадцать ";
      break;
    case 12:
      output += "двенадцать ";
      break;
    case 13:
      output += "тринадцать ";
      break;
    case 14:
      output += "четырнадцать ";
      break;
    case 15:
      output += "пятнадцать ";
      break;
    case 16:
      output += "шестнадцать ";
      break;
    case 17:
      output += "семнадцать ";
      break;
    case 18:
      output += "восемнадцать ";
      break;
    case 19:
      output += "девятнадцать ";
      break;
    }
  } else {
    switch (hundred % 10) {
    case 1:
      output += "один ";
      break;
    case 2:
      output += "два ";
      break;
    case 3:
      output += "три ";
      break;
    case 4:
      output += "четыре ";
      break;
    case 5:
      output += "пять ";
      break;
    case 6:
      output += "шесть ";
      break;
    case 7:
      output += "семь ";
      break;
    case 8:
      output += "восемь ";
      break;
    case 9:
      output += "девять ";
      break;
    }
  }
}
void hundred_to_string_m(int hundred) {

  switch (hundred / 100) {
  case 1:
    output += "cто ";
    break;
  case 2:
    output += "двести ";
    break;
  case 3:
    output += "триста ";
    break;
  case 4:
    output += "четыреста ";
    break;
  case 5:
    output += "пятьсот ";
    break;
  case 6:
    output += "шестьсот ";
    break;
  case 7:
    output += "семьсот ";
    break;
  case 8:
    output += "восемьсот ";
    break;
  case 9:
    output += "девятьсот ";
    break;
  }
  switch ((hundred % 100) / 10) {
  case 2:
    output += "двадцать ";
    break;
  case 3:
    output += "тридцать ";
    break;
  case 4:
    output += "сорок ";
    break;
  case 5:
    output += "пятьдесят ";
    break;
  case 6:
    output += "шестьдесят ";
    break;
  case 7:
    output += "семьдесят ";
    break;
  case 8:
    output += "восемьдесят ";
    break;
  case 9:
    output += "девяносто ";
    break;
  }
  if (hundred % 100 >= 10 & hundred % 100 < 20) {
    switch (hundred % 100) {
    case 10:
      output += "десять ";
      break;
    case 11:
      output += "одиннадцать ";
      break;
    case 12:
      output += "двенадцать ";
      break;
    case 13:
      output += "тринадцать ";
      break;
    case 14:
      output += "четырнадцать ";
      break;
    case 15:
      output += "пятнадцать ";
      break;
    case 16:
      output += "шестнадцать ";
      break;
    case 17:
      output += "семнадцать ";
      break;
    case 18:
      output += "восемнадцать ";
      break;
    case 19:
      output += "девятнадцать ";
      break;
    }
  } else {
    switch (hundred % 10) {
    case 1:
      output += "одна ";
      break;
    case 2:
      output += "две ";
      break;
    case 3:
      output += "три ";
      break;
    case 4:
      output += "четыре ";
      break;
    case 5:
      output += "пять ";
      break;
    case 6:
      output += "шесть ";
      break;
    case 7:
      output += "семь ";
      break;
    case 8:
      output += "восемь ";
      break;
    case 9:
      output += "девять ";
      break;
    }
  }
}

void rublya_or_rubley(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "рублей ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "рубль ";
    return;
  case 2:
  case 3:
  case 4:
    output += "рубля ";
    return;
  default:
    output += "рублей ";
    return;
  }
}

void kopeyki_or_kopeek(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "копеек ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "копейка ";
    return;
  case 2:
  case 3:
  case 4:
    output += "копейки ";
    return;
  default:
    output += "копеек ";
    return;
  }
}

void trillion_or_trillionov(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "триллионов ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "триллион ";
    return;
  case 2:
  case 3:
  case 4:
    output += "триллиона ";
    return;
  default:
    output += "триллионов ";
    return;
  }
}

void milliardof_or_milliard(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "миллиардов ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "миллиард ";
    return;
  case 2:
  case 3:
  case 4:
    output += "миллиарда ";
    return;
  default:
    output += "миллиардов ";
    return;
  }
}

void million_or_millionov(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "миллионов ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "миллион ";
    return;
  case 2:
  case 3:
  case 4:
    output += "миллиона ";
    return;
  default:
    output += "миллионов ";
    return;
  }
}

void tysyach_or_tysyachey(int n) {
  switch (n % 100) {
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
  case 18:
  case 19:
    output += "тысяч ";
    return;
  }
  switch (n % 10) {
  case 1:
    output += "тысяча ";
    return;
  case 2:
  case 3:
  case 4:
    output += "тысячи ";
    return;
  default:
    output += "тысяч ";
    return;
  }
}