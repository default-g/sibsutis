#include "endings.h"
#include <algorithm>
#include <climits>
#include <cmath>
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <vector>

using namespace std;

vector<int> split_the_price(unsigned long long int price, int kopeyki) {
  vector<int> splitted_price;
  while (price > 0) {
    splitted_price.push_back(price % 1000);
    price /= 1000;
  }

  reverse(splitted_price.begin(), splitted_price.end());
  splitted_price.push_back(kopeyki);
  return splitted_price;
}

vector<int> price_input(string input) {
  unsigned long long rubles = 0;
  if (stoull(input) <= ULLONG_MAX)
    rubles = stoull(input);
  int kopeyki = 0;
  if (input.find(".") != std::string::npos)
    kopeyki = atoi(input.substr(input.find('.') + 1).c_str());
  if (kopeyki >= 100)
    kopeyki = -1;
  vector<int> price = split_the_price(rubles, kopeyki);
  return price;
}

string read_price(vector<int> price) {
  bool flag_for_rubles = false;
  for (int i = 0; i < price.size() - 1; i++) {
    switch (price.size() - i - 2) {
    case 4:
      if (price[i]) {
        hundred_to_string(price[i]);
        trillion_or_trillionov(price[i]);
      }
      break;
    case 3:
      if (price[i]) {
        hundred_to_string(price[i]);
        milliardof_or_milliard(price[i]);
      }
      break;
    case 2:
      if (price[i]) {
        hundred_to_string(price[i]);
        million_or_millionov(price[i]);
      }
      break;
    case 1:
      if (price[i]) {
        hundred_to_string_m(price[i]);
        tysyach_or_tysyachey(price[i]);
      }
      break;
    case 0:
      if (price[i]) {
        hundred_to_string(price[i]);
        rublya_or_rubley(price[i]);
        flag_for_rubles = true;
      }
      break;
    }
  }
  if (!flag_for_rubles && (price.size() > 1))
    output += "рублей ";
  if (price[price.size() - 1] > 0) {
    hundred_to_string_m(price[price.size() - 1]);
    kopeyki_or_kopeek(price[price.size() - 1]);
  }

  string str_new = output;
  output.clear();
  return str_new;
}

int main() {
  ifstream fin("input.txt");
  ofstream fout("output.txt");
  while (!fin.eof()) {
    string inp;
    fin >> inp;
    auto price = price_input(inp);
    fout << read_price(price) << endl;
  }
  return 0;
}